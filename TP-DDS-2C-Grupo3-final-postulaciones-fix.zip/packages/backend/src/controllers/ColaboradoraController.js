import { ColaboradoraService } from "../services/ColaboradoraService.js";
import { cookieOpciones } from "../services/AuthService.js";

export class ColaboradoraController {
  static async eliminarCuenta(req, res) {
    await ColaboradoraService.eliminarCuenta(
      req.params.id,
      req.cuenta._id,
    );

    res
      .clearCookie("cav_session", {
        ...cookieOpciones(),
        maxAge: undefined,
      })
      .status(204)
      .end();
  }
  static async actualizarContactos(req, res) {
    res.json(
      await ColaboradoraService.actualizarContactos(req.params.id, req.body),
    );
  }

  static async actualizar(req, res) {
    res.json(await ColaboradoraService.actualizar(req.params.id, req.body));
  }

  static async crear(req, res) {
    res.status(201).json(await ColaboradoraService.crearColaboradora(req.body));
  }

  static async listar(req, res) {
    res.json(await ColaboradoraService.listar());
  }

  static async obtener(req, res) {
    res.json(await ColaboradoraService.obtenerPorId(req.params.id));
  }

  static async agregarHabilidad(req, res) {
    res
      .status(201)
      .json(
        await ColaboradoraService.agregarHabilidad(req.params.id, req.body),
      );
  }

  static async actualizarExperienciaHabilidades(req, res) {
    res.json(
      await ColaboradoraService.actualizarExperienciaHabilidades(
        req.params.id,
        req.body.experienciaHabilidades,
      ),
    );
  }

  static async agregarMedioContacto(req, res) {
    res
      .status(201)
      .json(
        await ColaboradoraService.agregarMedioContacto(req.params.id, req.body),
      );
  }

  static async actualizarPreferencias(req, res) {
    res.json(
      await ColaboradoraService.actualizarPreferencias(req.params.id, req.body),
    );
  }
}
