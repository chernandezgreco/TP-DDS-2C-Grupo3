// Script semilla: borra las colecciones y carga los datos iniciales.
// Uso: npm run seed (toma MONGO_URI del .env). Cuidado: pisa todo lo que haya en esa base.
import "dotenv/config";
import mongoose from "mongoose";
import { nuevoId } from "../services/ids.js";
import { conectarMongo } from "../config/mongo.js";
import {
    ColaboracionModel,
    ColaboradoraModel,
    ColectivoModel,
    HabilidadModel,
    NotificacionModel,
    ProyectoModel,
    TareaModel,
} from "../models/indexModel.js";
import { Habilidad } from "../domain/Habilidad/Habilidad.js";
import { Colectivo } from "../domain/Colectivo/Colectivo.js";
import { Colaboradora } from "../domain/Colaboradora/Colaboradora.js";
import { MedioContacto } from "../domain/Colaboradora/MedioContacto.js";
import { Proyecto } from "../domain/Proyecto/Proyecto.js";
import { EstadoProyecto } from "../domain/Proyecto/EstadoProyecto.js";
import { Colaboracion } from "../domain/Colaboracion/Colaboracion.js";
import { Notificacion } from "../domain/Notificacion/Notificacion.js";
import { Tarea } from "../domain/Tarea/Tarea.js";
import { aDocumento, crearPerfil } from "../services/ProyectoService.js";
import { cargarLogrosIniciales } from "./logros.js";
import { COLABORACIONES, COLABORADORAS, COLECTIVOS, HABILIDADES, IDS, NOTIFICACIONES, PROYECTOS, TAREAS } from "./datos.js";

// cada entidad se arma con su clase de dominio, así los datos semilla pasan por las mismas validaciones

const habilidades = HABILIDADES.map((h) => new Habilidad(Habilidad.codigoPara(h.titulo), h.titulo, h.descripcion));

const colectivos = COLECTIVOS.map((c) => new Colectivo(c.id, c.nombre, c.descripcion, c.ubicacion, c.tipo, c.etiquetas));

const colaboradoras = COLABORADORAS.map((c) => new Colaboradora(
    c.id,
    c.nombreFantasia,
    c.github,
    c.nombreApellido,
    c.habilidades,
    c.pronombres,
    c.presentacion,
    c.mediosContacto.map((m) => new MedioContacto(m.tipo, m.valor)),
    c.aceptaMensajeria
));

const proyectos = PROYECTOS.map((p) => new Proyecto(
    p.id,
    p.titulo,
    p.descripcion,
    p.colectivoId,
    p.perfiles.map((perfil) => crearPerfil(nuevoId(), perfil)),
    [],
    true,
    EstadoProyecto.ACTIVO,
    null,
    p.etiquetas,
));

// las colaboraciones se arman con los proyectos activos; recién después se cierran los finalizados
const colaboraciones = COLABORACIONES.map(({ proyectoId, colaboradoraId }) => {
    const proyecto = proyectos.find((p) => p.id === proyectoId);
    const colaboradora = colaboradoras.find((c) => c.id === colaboradoraId);
    const perfil = proyecto.perfilParaAnotar(colaboradora);
    return new Colaboracion(null, proyecto.id, perfil.id, colaboradora.id);
});

PROYECTOS.filter((p) => p.finalizado).forEach((p) => proyectos.find((proyecto) => proyecto.id === p.id).cerrar());

// las tareas sin terminar de un proyecto finalizado quedan cerradas, igual que al finalizarlo por la API
const dia = (texto) => new Date(`${texto}T00:00:00.000Z`);
const tareas = TAREAS.map((t) => {
    const tarea = new Tarea(null, t.proyectoId, t.nombre, t.descripcion, dia(t.fechaInicio), dia(t.fechaFin), t.responsableId, t.estado);
    if (!proyectos.find((proyecto) => proyecto.id === t.proyectoId).estaActivo()) {
        tarea.cerrar();
    }
    return tarea;
});

const notificaciones = NOTIFICACIONES.map((n) => new Notificacion(null, n.colaboradoraId, n.colectivoId, n.proyectoId, n.texto));

// referencias: todas las habilidades usadas tienen que existir
const codigos = habilidades.map((h) => h.codigo);
const usadas = [
    ...colaboradoras.flatMap((c) => c.habilidades),
    ...proyectos.flatMap((p) => p.perfiles.flatMap((perfil) => perfil.todasLasHabilidades())),
];
const inexistentes = usadas.filter((codigo) => !codigos.includes(codigo));
if (inexistentes.length > 0) {
    throw new Error(`Los datos semilla usan habilidades que no existen: ${[...new Set(inexistentes)].join(", ")}`);
}

// referencias: el responsable de una tarea tiene que colaborar en ese proyecto
const sinColaboracion = TAREAS.filter(
    (t) => t.responsableId && !COLABORACIONES.some((c) => c.proyectoId === t.proyectoId && c.colaboradoraId === t.responsableId),
);
if (sinColaboracion.length > 0) {
    throw new Error(`Los datos semilla tienen tareas con responsables que no colaboran en el proyecto: ${sinColaboracion.map((t) => t.nombre).join(", ")}`);
}

await conectarMongo();
console.log(`Cargando datos semilla en la base "${mongoose.connection.name}"...`);

await Promise.all([
    HabilidadModel.deleteMany({}),
    ColectivoModel.deleteMany({}),
    ColaboradoraModel.deleteMany({}),
    ProyectoModel.deleteMany({}),
    ColaboracionModel.deleteMany({}),
    NotificacionModel.deleteMany({}),
    TareaModel.deleteMany({}),
]);

await HabilidadModel.insertMany(habilidades.map((h) => ({ codigo: h.codigo, titulo: h.titulo, descripcion: h.descripcion })));

await ColectivoModel.insertMany(colectivos.map((c) => ({
    _id: c.id,
    nombre: c.nombre,
    descripcion: c.descripcion,
    ubicacion: c.ubicacion,
    tipo: c.tipo,
    etiquetas: c.etiquetas,
})));

await ColaboradoraModel.insertMany(colaboradoras.map((c) => ({
    _id: c.id,
    nombreFantasia: c.nombreFantasia,
    github: c.github,
    nombreApellido: c.nombreApellido,
    habilidades: c.habilidades,
    pronombres: c.pronombres,
    presentacion: c.presentacion,
    aceptaMensajeria: c.aceptaMensajeria,
    mediosContacto: c.mediosContacto.map((m) => ({ tipo: m.tipo, valor: m.valor })),
})));

await ProyectoModel.insertMany(proyectos.map((p) => ({ _id: p.id, ...aDocumento(p) })));

await ColaboracionModel.insertMany(colaboraciones.map((c) => ({
    proyectoId: c.proyectoId,
    perfilId: c.perfilId,
    colaboradoraId: c.colaboradoraId,
    estado: c.estado,
    fechaCreacion: c.fechaCreacion,
})));

await TareaModel.insertMany(tareas.map((t) => ({
    proyectoId: t.proyectoId,
    nombre: t.nombre,
    descripcion: t.descripcion,
    fechaInicio: t.fechaInicio,
    fechaFin: t.fechaFin,
    responsableId: t.responsableId,
    estado: t.estado,
})));

await NotificacionModel.insertMany(notificaciones.map((n) => ({
    colaboradoraId: n.colaboradoraId,
    colectivoId: n.colectivoId,
    proyectoId: n.proyectoId,
    texto: n.texto,
    fecha: n.fecha,
})));

await cargarLogrosIniciales(IDS.proyectos.webDonaciones);

console.log(
    `Listo: ${habilidades.length} habilidades, ${colectivos.length} colectivos, ${colaboradoras.length} colaboradoras, ` +
    `${proyectos.length} proyectos, ${tareas.length} tareas, ${colaboraciones.length} colaboraciones, ${notificaciones.length} notificaciones y logros iniciales.`
);

await mongoose.disconnect();
